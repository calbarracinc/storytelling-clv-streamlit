
# Storytelling CLV · Streamlit App

Aplicación de Streamlit para visualizar y narrar *Customer Lifetime Value (CLV)* con 3+ slides interactivas (Distribución, Pareto, Evolución temporal y CLV vs Frecuencia).

## Archivos
- `streamlit_app.py`: código principal de la app.
- `requirements.txt`: dependencias para desplegar en Streamlit Community Cloud.
- `CLV.csv`: dataset de ejemplo / tu dataset.

## Ejecutar localmente
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Despliegue con **Streamlit Community Cloud** (desde GitHub)
1. Crea un repositorio en GitHub y sube estos archivos: `streamlit_app.py`, `requirements.txt` y tu `CLV.csv`.
2. Ve a https://share.streamlit.io (o https://streamlit.io/cloud) e inicia sesión con tu cuenta de GitHub.
3. Haz clic en **New app** y selecciona:
   - **Repository**: `<tu_usuario>/<tu_repo>`
   - **Branch**: `main` (o la que uses)
   - **Main file path**: `streamlit_app.py`
4. Pulsa **Deploy**. Se generará un **link público** a tu app (del tipo `https://<tu-usuario>-<tu-repo>-<hash>.streamlit.app`).

> Si no deseas subir `CLV.csv` al repo, déjalo vacío y usa el cargador de archivos en la barra lateral para subirlo al iniciar la app.

## Uso dentro de la app
1. En la barra lateral, sube o asegúrate de tener `CLV.csv` en la raíz.
2. Asigna las columnas (ID, CLV, Fecha, etc.).
3. Explora las *Slides*: **Distribución**, **Pareto**, **Evolución temporal**, **CLV vs Frecuencia**.
4. Descarga tus **KPIs** y **dataset a nivel cliente** desde la barra lateral.
